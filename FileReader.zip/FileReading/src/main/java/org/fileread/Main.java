package org.fileread;

public class Main {
    public static void main(String[] args) {
        JsonFileRead jsonFileRead = new JsonFileRead();
        jsonFileRead.readJson();
    }
}